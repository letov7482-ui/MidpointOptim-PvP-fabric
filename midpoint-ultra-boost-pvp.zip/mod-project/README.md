# MidpointUltraBoostPvP

Клиентский FPS-буст мод для Fabric (Minecraft 1.21.4).

- **VRAM-Squeeze** — снижает нагрузку на видеопамять, огрубляя mip-уровни блочного атласа текстур.
- **FrameLock** — во время боя (10 сек после получения урона) агрессивно отсекает рендер всего, что дальше `frameLockDistance` от игрока.

## Как собрать через GitHub Actions

1. Создайте новый репозиторий на GitHub и залейте туда содержимое этой папки целиком (включая `.github/workflows/build.yml`).
2. Ничего дополнительно настраивать не нужно — workflow запускается автоматически:
   - при каждом `push` в любую ветку;
   - при каждом Pull Request;
   - вручную кнопкой **Run workflow** во вкладке **Actions** (workflow_dispatch).
3. Через 3-6 минут откройте вкладку **Actions -> (последний запуск) -> Artifacts** — там будет
   `midpoint-ultra-boost-pvp.zip`, внутри которого лежит готовый `.jar` мода.

## Локальная сборка (опционально)

Если Gradle Wrapper не закоммичен, самый простой способ собрать локально —
установить Gradle 8.11+ и JDK 21, затем в корне проекта выполнить:

```bash
gradle build
```

Готовый файл появится в `build/libs/midpoint-ultra-boost-pvp-1.0.0.jar`.

## Настройки мода

Настройки доступны через ModMenu (кнопка **Configure** у мода в списке):

| Параметр            | Тип     | Диапазон | По умолчанию |
|---------------------|---------|----------|--------------|
| globalEnabled       | bool    | —        | true         |
| enableVramSqueeze   | bool    | —        | true         |
| enableFrameLock     | bool    | —        | true         |
| squeezeDistance     | int     | 8–32     | 16           |
| frameLockDistance   | int     | 16–64    | 30           |
