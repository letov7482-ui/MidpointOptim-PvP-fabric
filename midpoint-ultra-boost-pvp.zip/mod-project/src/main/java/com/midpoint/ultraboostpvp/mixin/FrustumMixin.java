package com.midpoint.ultraboostpvp.mixin;

import com.midpoint.ultraboostpvp.CombatStateManager;
import com.midpoint.ultraboostpvp.ModConfig;
import com.midpoint.ultraboostpvp.UltraBoostPvPClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Механика FrameLock ("Изоляция арены").
 *
 * Frustum.isVisible(Box) — стандартный метод ванильной игры, который вызывается
 * для каждого чанка/блок-сущности/энтити, чтобы решить, попадает ли он
 * в поле зрения камеры и стоит ли вообще его рендерить.
 *
 * Мы НЕ трогаем саму математику видимости (frustum culling), а просто
 * дополнительно "выключаем" всё, что дальше frameLockDistance от игрока,
 * когда включён FrameLock и игрок находится в бою. Это безопасно, потому что
 * мы лишь возвращаем false из уже существующего булева метода — ровно так же,
 * как сама игра делает это для объектов вне обычного frustum.
 */
@Mixin(Frustum.class)
public abstract class FrustumMixin {

    // Позиция камеры, от которой Frustum считает видимость.
    // Поля объявлены в самом классе Frustum как private double x, y, z.
    @Shadow
    private double x;
    @Shadow
    private double y;
    @Shadow
    private double z;

    @Inject(method = "isVisible(Lnet/minecraft/util/math/Box;)Z", at = @At("HEAD"), cancellable = true)
    private void midpoint$forceCullFarObjects(Box box, CallbackInfoReturnable<Boolean> cir) {
        ModConfig config = UltraBoostPvPClient.getConfig();

        // Мод целиком выключен или FrameLock выключен — ничего не делаем
        if (config == null || !config.globalEnabled || !config.enableFrameLock) {
            return;
        }

        // FrameLock работает только пока игрок в бою (см. CombatStateManager)
        if (!CombatStateManager.INSTANCE.isInCombat()) {
            return;
        }

        double frameLockDistance = config.frameLockDistance;

        // Считаем расстояние от камеры до ближайшей точки бокса (без квадратного корня,
        // сравниваем квадраты расстояний — это дешевле и не требует лишней математики)
        double dx = clampDelta(x, box.minX, box.maxX);
        double dy = clampDelta(y, box.minY, box.maxY);
        double dz = clampDelta(z, box.minZ, box.maxZ);

        double distanceSquared = dx * dx + dy * dy + dz * dz;
        double limitSquared = frameLockDistance * frameLockDistance;

        if (distanceSquared > limitSquared) {
            // Объект дальше радиуса изоляции арены — принудительно считаем его невидимым.
            // Это отменяет вызов ванильного метода и возвращает false вместо реального результата.
            cir.setReturnValue(false);
        }
    }

    /**
     * Возвращает 0, если камера уже находится внутри диапазона [min, max] по данной оси,
     * иначе — расстояние до ближайшей границы. Используется для вычисления
     * кратчайшего расстояния от точки до AABB-бокса.
     */
    private static double clampDelta(double point, double min, double max) {
        if (point < min) {
            return min - point;
        }
        if (point > max) {
            return point - max;
        }
        return 0.0;
    }
}
