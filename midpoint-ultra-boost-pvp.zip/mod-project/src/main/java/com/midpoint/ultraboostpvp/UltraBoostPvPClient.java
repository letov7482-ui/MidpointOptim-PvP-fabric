package com.midpoint.ultraboostpvp;

import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Клиентская точка входа MidpointUltraBoostPvP.
 *
 * Здесь:
 *  1) регистрируется конфиг (Cloth Config);
 *  2) каждый клиентский тик обновляется CombatStateManager, который
 *     решает, находится ли игрок "в бою" (для механики FrameLock).
 */
public class UltraBoostPvPClient implements ClientModInitializer {

    public static final String MOD_ID = "midpoint-ultra-boost-pvp";

    @Override
    public void onInitializeClient() {
        // Регистрируем конфиг в Cloth Config / AutoConfig
        AutoConfig.register(ModConfig.class, GsonConfigSerializer::new);

        // Подписываемся на конец каждого клиентского тика, чтобы обновлять таймер боя
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientPlayerEntity player = client.player;
            CombatStateManager.INSTANCE.update(player);
        });
    }

    /**
     * Удобный статический геттер конфига — используется из миксинов,
     * т.к. AutoConfig хранит один общий инстанс конфига.
     */
    public static ModConfig getConfig() {
        return AutoConfig.getConfigHolder(ModConfig.class).getConfig();
    }

    /**
     * Безопасно получить текущего клиента (для миксинов).
     */
    public static MinecraftClient client() {
        return MinecraftClient.getInstance();
    }
}
