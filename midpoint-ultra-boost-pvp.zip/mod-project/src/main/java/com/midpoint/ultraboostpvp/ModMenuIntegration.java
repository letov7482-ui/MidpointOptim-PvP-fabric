package com.midpoint.ultraboostpvp;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.autoconfig.AutoConfig;

/**
 * Точка входа "modmenu" — привязывает экран настроек Cloth Config
 * к кнопке "Configure" в списке модов ModMenu.
 */
public class ModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        // AutoConfig сам построит экран настроек на основе аннотаций в ModConfig
        return parent -> AutoConfig.getConfigScreen(ModConfig.class, parent).get();
    }
}
