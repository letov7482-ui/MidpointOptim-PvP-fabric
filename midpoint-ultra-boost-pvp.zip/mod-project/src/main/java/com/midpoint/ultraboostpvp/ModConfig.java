package com.midpoint.ultraboostpvp;

import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry;

/**
 * Конфигурация мода MidpointUltraBoostPvP.
 * Хранится в config/midpoint-ultra-boost-pvp.json (создаётся автоматически Cloth Config API).
 */
@Config(name = "midpoint-ultra-boost-pvp")
public class ModConfig implements ConfigData {

    // --- Глобальные переключатели ---

    @ConfigEntry.Gui.Tooltip
    public boolean globalEnabled = true;

    @ConfigEntry.Gui.Tooltip
    public boolean enableVramSqueeze = true;

    @ConfigEntry.Gui.Tooltip
    public boolean enableFrameLock = true;

    // --- Слайдеры дистанций ---

    @ConfigEntry.Gui.Tooltip
    @ConfigEntry.BoundedDiscrete(min = 8, max = 32)
    public int squeezeDistance = 16;

    @ConfigEntry.Gui.Tooltip
    @ConfigEntry.BoundedDiscrete(min = 16, max = 64)
    public int frameLockDistance = 30;
}
