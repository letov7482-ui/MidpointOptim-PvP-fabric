package com.midpoint.ultraboostpvp;

import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Отслеживает, находится ли локальный игрок "в бою".
 *
 * Логика простая и безопасная: без миксинов в систему урона мы просто
 * сравниваем здоровье игрока на этом тике с предыдущим. Если оно упало —
 * значит игрок получил урон, и мы запускаем/продлеваем таймер боя на 10 секунд.
 *
 * Таймер считается в игровых тиках (20 тиков = 1 секунда).
 */
public class CombatStateManager {

    // Синглтон — состояние боя нужно только одно, на клиенте
    public static final CombatStateManager INSTANCE = new CombatStateManager();

    private static final int COMBAT_DURATION_TICKS = 20 * 10; // 10 секунд

    private float lastKnownHealth = -1.0F;
    private int combatTicksLeft = 0;

    private CombatStateManager() {
    }

    /**
     * Вызывается каждый клиентский тик (см. UltraBoostPvPClient).
     * Если игрок получил урон — сбрасывает (продлевает) таймер боя до максимума.
     * Иначе — уменьшает таймер на 1 тик.
     */
    public void update(ClientPlayerEntity player) {
        if (player == null) {
            lastKnownHealth = -1.0F;
            combatTicksLeft = 0;
            return;
        }

        float currentHealth = player.getHealth();

        // Первая инициализация — просто запоминаем здоровье, не считаем это уроном
        if (lastKnownHealth < 0.0F) {
            lastKnownHealth = currentHealth;
        } else if (currentHealth < lastKnownHealth) {
            // Игрок получил урон -> сбрасываем таймер боя на полную длительность
            combatTicksLeft = COMBAT_DURATION_TICKS;
        }

        lastKnownHealth = currentHealth;

        if (combatTicksLeft > 0) {
            combatTicksLeft--;
        }
    }

    /**
     * @return true, если игрок получил урон менее 10 секунд назад
     */
    public boolean isInCombat() {
        return combatTicksLeft > 0;
    }

    /**
     * Принудительно завершить состояние боя (например, при выходе из мира).
     */
    public void reset() {
        lastKnownHealth = -1.0F;
        combatTicksLeft = 0;
    }
}
