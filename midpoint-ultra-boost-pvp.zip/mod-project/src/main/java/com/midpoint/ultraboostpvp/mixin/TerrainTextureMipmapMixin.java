package com.midpoint.ultraboostpvp.mixin;

import com.midpoint.ultraboostpvp.ModConfig;
import com.midpoint.ultraboostpvp.UltraBoostPvPClient;
import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.SpriteAtlasTexture;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Механика VRAM-Squeeze ("Сжатие текстур").
 *
 * ВАЖНОЕ ТЕХНИЧЕСКОЕ ПОЯСНЕНИЕ (чтобы не создавать иллюзий):
 * В ванильном рендер-пайплайне Minecraft у блочного атласа текстур ЗАРАНЕЕ
 * запечён фиксированный набор mip-уровней (при старте/перезагрузке ресурспаков),
 * и весь terrain-атлас рендерится ОДНОЙ привязкой текстуры на кадр — то есть
 * "подменить mip-уровень для одного конкретного далёкого блока", не трогая
 * соседние блоки того же draw call'а, средствами ванильной игры и Mixin
 * (без вертексных шейдеров/кастомной геометрии) невозможно.
 *
 * Поэтому здесь реализован безопасный и честный аналог с тем же результатом
 * по VRAM/GPU-нагрузке: когда VRAM-Squeeze включён, мы через штатный (не "сырой")
 * враппер GlStateManager (это обёртка Mojang над OpenGL, используемая всей игрой)
 * выставляем текстуре LOD-bias, вынуждая GPU заранее использовать более грубые
 * (низкодетальные) mip-уровни атласа — это и есть "принудительный сверхнизкий
 * mip" из ТЗ, только применяется к атласу целиком, а не поблочно.
 *
 * ЦЕЛЬ МИКСИНА: AbstractTexture.bindTexture() — это стабильный, НЕ обфусцированный
 * метод, который существует без изменений сигнатуры с версии 1.16 и присутствует
 * в 1.21.4. Он вызывается всякий раз, когда игра привязывает любую текстуру перед
 * рендером. Мы не трогаем произвольные текстуры (GUI, шрифты, скины) — а только
 * объекты класса SpriteAtlasTexture, к которому относится в т.ч. блочный атлас
 * (textures/atlas/blocks.png), поэтому GUI и скины не искажаются.
 *
 * Порог squeezeDistance используется как переключатель степени сжатия:
 * чем меньше squeezeDistance, тем агрессивнее (крупнее) bias.
 */
@Mixin(AbstractTexture.class)
public abstract class TerrainTextureMipmapMixin {

    @Inject(method = "bindTexture()V", at = @At("TAIL"))
    private void midpoint$applyVramSqueezeBias(CallbackInfo ci) {
        // Трогаем только текстуры-атласы (блоки, частицы и т.п.),
        // чтобы не портить GUI/шрифты/скины игроков.
        if (!(((Object) this) instanceof SpriteAtlasTexture)) {
            return;
        }

        ModConfig config = UltraBoostPvPClient.getConfig();
        if (config == null || !config.globalEnabled || !config.enableVramSqueeze) {
            // Если механика выключена — сбрасываем bias на 0 (обычное качество)
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_LOD_BIAS, 0.0F);
            return;
        }

        // squeezeDistance в диапазоне [8, 32] по конфигу.
        // Переводим его в bias в диапазоне [0.5 .. 4.0]: чем меньше дистанция
        // (агрессивнее настройка), тем сильнее прижимаем к грубым mip-уровням.
        int squeezeDistance = config.squeezeDistance;
        float bias = 4.0F - ((squeezeDistance - 8) / 24.0F) * 3.5F;
        bias = Math.max(0.5F, Math.min(4.0F, bias));

        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_LOD_BIAS, bias);
    }
}
