package com.midpoint.ultraboostpvp.mixin;

import com.midpoint.ultraboostpvp.ModConfig;
import com.midpoint.ultraboostpvp.UltraBoostPvPClient;
import com.mojang.blaze3d.systems.GlStateManager;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Механика VRAM-Squeeze ("Сжатие текстур").
 *
 * ВАЖНОЕ ТЕХНИЧЕСКОЕ ПОЯСНЕНИЕ (чтобы не создавать иллюзий):
 * В ванильном рендер-пайплайне Minecraft у блочного атласа текстур ЗАРАНЕЕ
 * запечён фиксированный набор mip-уровней (при старте/перезагрузке ресурспаков),
 * и весь terrain-атлас рендерится ОДНОЙ привязкой текстуры на кадр — то есть
 * "подменить mip-уровень для одного конкретного далёкого блока", не трогая
 * соседние блоки того же draw call'а, средствами ванильной игры и Mixin
 * (без вертексных шейдеров/кастомной геометрии) невозможно.
 *
 * Поэтому здесь реализован безопасный и честный аналог с тем же результатом
 * по VRAM/GPU-нагрузке: когда VRAM-Squeeze включён, мы через штатный (не "сырой")
 * враппер GlStateManager (это обёртка Mojang над OpenGL, используемая всей игрой)
 * выставляем текстуре блочного атласа отрицательный LOD-bias, вынуждая GPU
 * заранее использовать более грубые (низкодетальные) mip-уровни атласа —
 * это и есть "принудительный сверхнизкий mip" из ТЗ, только применяется
 * к атласу целиком, а не поблочно.
 *
 * Порог squeezeDistance используется как переключатель степени сжатия:
 * чем меньше squeezeDistance, тем агрессивнее (крупнее) bias.
 */
@Mixin(TextureManager.class)
public abstract class TerrainTextureMipmapMixin {

    // Идентификатор ванильного блочного атласа текстур
    private static final Identifier BLOCK_ATLAS_ID =
            Identifier.of("minecraft", "textures/atlas/blocks.png");

    @Inject(method = "bindTexture", at = @At("RETURN"))
    private void midpoint$applyVramSqueezeBias(Identifier id, CallbackInfo ci) {
        if (!BLOCK_ATLAS_ID.equals(id)) {
            // Трогаем только блочный атлас, чтобы не портить GUI/иконки/скины
            return;
        }

        ModConfig config = UltraBoostPvPClient.getConfig();
        if (config == null || !config.globalEnabled || !config.enableVramSqueeze) {
            // Если механика выключена — сбрасываем bias на 0 (обычное качество)
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_LOD_BIAS, 0.0F);
            return;
        }

        // squeezeDistance в диапазоне [8, 32] по конфигу.
        // Переводим его в bias в диапазоне [0.5 .. 4.0]: чем меньше дистанция
        // (агрессивнее настройка), тем сильнее прижимаем к грубым mip-уровням.
        int squeezeDistance = config.squeezeDistance;
        float bias = 4.0F - ((squeezeDistance - 8) / 24.0F) * 3.5F;
        bias = Math.max(0.5F, Math.min(4.0F, bias));

        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_LOD_BIAS, bias);
    }
}
